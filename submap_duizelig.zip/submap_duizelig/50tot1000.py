getal = 50
getal1 = 51
while getal < 1100:    
    print(getal)
    getal = getal1 + getal
    getal1 = getal1 + 1 
    